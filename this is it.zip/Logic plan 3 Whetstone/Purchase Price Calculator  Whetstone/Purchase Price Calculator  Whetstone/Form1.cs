﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Purchase_Price_Calculator__Whetstone
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void amountOfPurchaseTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        

        private void caculateButton_Click(object sender, EventArgs e)
        {
            decimal amountEntered;
            decimal amountPurchase;
            decimal discountAmount;
            decimal total;

            amountEntered = decimal.Parse(amountEnterTextBox.Text);
            amountPurchase = decimal.Parse(amountOfPurchaseTextBox.Text);
            discountAmount = decimal.Parse(discountAmountTextBox.Text);
            //total = (amountEntered / .10) - amountEntered;


      
                
        }
    }
}
