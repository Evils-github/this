﻿namespace Purchase_Price_Calculator__Whetstone
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.amountOfPurchaseEnteredLabel = new System.Windows.Forms.Label();
            this.AmountOfPurchaseLabel = new System.Windows.Forms.Label();
            this.TotalDiscountAmountLabel = new System.Windows.Forms.Label();
            this.totalOfSaleLabel = new System.Windows.Forms.Label();
            this.amountEnterTextBox = new System.Windows.Forms.TextBox();
            this.caculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.amountOfPurchaseTextBox = new System.Windows.Forms.TextBox();
            this.discountAmountTextBox = new System.Windows.Forms.TextBox();
            this.totalSaleTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // amountOfPurchaseEnteredLabel
            // 
            this.amountOfPurchaseEnteredLabel.AutoSize = true;
            this.amountOfPurchaseEnteredLabel.Location = new System.Drawing.Point(12, 23);
            this.amountOfPurchaseEnteredLabel.Name = "amountOfPurchaseEnteredLabel";
            this.amountOfPurchaseEnteredLabel.Size = new System.Drawing.Size(171, 20);
            this.amountOfPurchaseEnteredLabel.TabIndex = 0;
            this.amountOfPurchaseEnteredLabel.Text = "Amount of Purchase: $";
            this.amountOfPurchaseEnteredLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // AmountOfPurchaseLabel
            // 
            this.AmountOfPurchaseLabel.AutoSize = true;
            this.AmountOfPurchaseLabel.Location = new System.Drawing.Point(30, 156);
            this.AmountOfPurchaseLabel.Name = "AmountOfPurchaseLabel";
            this.AmountOfPurchaseLabel.Size = new System.Drawing.Size(158, 20);
            this.AmountOfPurchaseLabel.TabIndex = 1;
            this.AmountOfPurchaseLabel.Text = "Amount of Purchase:";
            // 
            // TotalDiscountAmountLabel
            // 
            this.TotalDiscountAmountLabel.AutoSize = true;
            this.TotalDiscountAmountLabel.Location = new System.Drawing.Point(30, 209);
            this.TotalDiscountAmountLabel.Name = "TotalDiscountAmountLabel";
            this.TotalDiscountAmountLabel.Size = new System.Drawing.Size(175, 20);
            this.TotalDiscountAmountLabel.TabIndex = 2;
            this.TotalDiscountAmountLabel.Text = "Total Discount Amount:";
            // 
            // totalOfSaleLabel
            // 
            this.totalOfSaleLabel.AutoSize = true;
            this.totalOfSaleLabel.Location = new System.Drawing.Point(30, 250);
            this.totalOfSaleLabel.Name = "totalOfSaleLabel";
            this.totalOfSaleLabel.Size = new System.Drawing.Size(125, 20);
            this.totalOfSaleLabel.TabIndex = 3;
            this.totalOfSaleLabel.Text = "Total of the Sale";
            // 
            // amountEnterTextBox
            // 
            this.amountEnterTextBox.Location = new System.Drawing.Point(214, 23);
            this.amountEnterTextBox.Name = "amountEnterTextBox";
            this.amountEnterTextBox.Size = new System.Drawing.Size(100, 26);
            this.amountEnterTextBox.TabIndex = 4;
            this.amountEnterTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // caculateButton
            // 
            this.caculateButton.Location = new System.Drawing.Point(343, 23);
            this.caculateButton.Name = "caculateButton";
            this.caculateButton.Size = new System.Drawing.Size(168, 26);
            this.caculateButton.TabIndex = 5;
            this.caculateButton.Text = "Calculate Purchase";
            this.caculateButton.UseVisualStyleBackColor = true;
            this.caculateButton.Click += new System.EventHandler(this.caculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(343, 91);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(108, 38);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // amountOfPurchaseTextBox
            // 
            this.amountOfPurchaseTextBox.Location = new System.Drawing.Point(214, 156);
            this.amountOfPurchaseTextBox.Name = "amountOfPurchaseTextBox";
            this.amountOfPurchaseTextBox.ReadOnly = true;
            this.amountOfPurchaseTextBox.Size = new System.Drawing.Size(100, 26);
            this.amountOfPurchaseTextBox.TabIndex = 7;
            this.amountOfPurchaseTextBox.TextChanged += new System.EventHandler(this.amountOfPurchaseTextBox_TextChanged);
            // 
            // discountAmountTextBox
            // 
            this.discountAmountTextBox.Location = new System.Drawing.Point(214, 203);
            this.discountAmountTextBox.Name = "discountAmountTextBox";
            this.discountAmountTextBox.ReadOnly = true;
            this.discountAmountTextBox.Size = new System.Drawing.Size(100, 26);
            this.discountAmountTextBox.TabIndex = 8;
            // 
            // totalSaleTextBox
            // 
            this.totalSaleTextBox.Location = new System.Drawing.Point(214, 250);
            this.totalSaleTextBox.Name = "totalSaleTextBox";
            this.totalSaleTextBox.ReadOnly = true;
            this.totalSaleTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalSaleTextBox.TabIndex = 9;
            
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.totalSaleTextBox);
            this.Controls.Add(this.discountAmountTextBox);
            this.Controls.Add(this.amountOfPurchaseTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.caculateButton);
            this.Controls.Add(this.amountEnterTextBox);
            this.Controls.Add(this.totalOfSaleLabel);
            this.Controls.Add(this.TotalDiscountAmountLabel);
            this.Controls.Add(this.AmountOfPurchaseLabel);
            this.Controls.Add(this.amountOfPurchaseEnteredLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label amountOfPurchaseEnteredLabel;
        private System.Windows.Forms.Label AmountOfPurchaseLabel;
        private System.Windows.Forms.Label TotalDiscountAmountLabel;
        private System.Windows.Forms.Label totalOfSaleLabel;
        private System.Windows.Forms.TextBox amountEnterTextBox;
        private System.Windows.Forms.Button caculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox amountOfPurchaseTextBox;
        private System.Windows.Forms.TextBox discountAmountTextBox;
        private System.Windows.Forms.TextBox totalSaleTextBox;
    }
}

