﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Purchase_Price_Calculator___Whetstone
{
    public partial class Form1 : Form
    {
        private readonly object totalOfSaleLabel;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            const decimal DISCOUNT = .10m;

            decimal amountOfPurchase;
            decimal amountOfPurchaseRepeat;
            decimal discountAmount;
            decimal totalOfSale;

            amountOfPurchase = decimal.Parse(amountOfPurchaseRepeatTextBox.Text);
            amountOfPurchaseRepeat = decimal.Parse(amountOfPurchaseRepeatTextBox.Text);
            discountAmount = decimal.Parse(totalDiscountAmountTextBox.Text);
            totalOfSale = decimal.Parse(totalOfSaleTextBox.Text);

            // calculate
            totalOfSale = amountOfPurchase / DISCOUNT - amountOfPurchase;
            totalDiscountAmountLabel.Text = totalOfSale.ToString("c");


        }   

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
    }
}
