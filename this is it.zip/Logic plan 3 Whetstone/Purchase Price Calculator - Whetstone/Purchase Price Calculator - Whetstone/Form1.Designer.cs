﻿namespace Purchase_Price_Calculator___Whetstone
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.amountOfPurchaseLabel = new System.Windows.Forms.Label();
            this.amountOfPurchaseTextBox = new System.Windows.Forms.TextBox();
            this.AmountRepeat = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.amountOfPurchaseRepeatTextBox = new System.Windows.Forms.TextBox();
            this.totalDiscountAmountLabel = new System.Windows.Forms.Label();
            this.totalDiscountAmountTextBox = new System.Windows.Forms.TextBox();
            this.TotalOfSaleLabel = new System.Windows.Forms.Label();
            this.totalOfSaleTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // amountOfPurchaseLabel
            // 
            this.amountOfPurchaseLabel.AutoSize = true;
            this.amountOfPurchaseLabel.Location = new System.Drawing.Point(12, 24);
            this.amountOfPurchaseLabel.Name = "amountOfPurchaseLabel";
            this.amountOfPurchaseLabel.Size = new System.Drawing.Size(171, 20);
            this.amountOfPurchaseLabel.TabIndex = 0;
            this.amountOfPurchaseLabel.Text = "Amount of Purchase: $";
            // 
            // amountOfPurchaseTextBox
            // 
            this.amountOfPurchaseTextBox.Location = new System.Drawing.Point(203, 18);
            this.amountOfPurchaseTextBox.Name = "amountOfPurchaseTextBox";
            this.amountOfPurchaseTextBox.Size = new System.Drawing.Size(100, 26);
            this.amountOfPurchaseTextBox.TabIndex = 1;
            // 
            // AmountRepeat
            // 
            this.AmountRepeat.AutoSize = true;
            this.AmountRepeat.Location = new System.Drawing.Point(12, 164);
            this.AmountRepeat.Name = "AmountRepeat";
            this.AmountRepeat.Size = new System.Drawing.Size(158, 20);
            this.AmountRepeat.TabIndex = 2;
            this.AmountRepeat.Text = "Amount of Purchase:";
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(343, 17);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(157, 34);
            this.calculateButton.TabIndex = 3;
            this.calculateButton.Text = "Calculate Purchase";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(356, 96);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(98, 38);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // amountOfPurchaseRepeatTextBox
            // 
            this.amountOfPurchaseRepeatTextBox.Location = new System.Drawing.Point(222, 161);
            this.amountOfPurchaseRepeatTextBox.Name = "amountOfPurchaseRepeatTextBox";
            this.amountOfPurchaseRepeatTextBox.ReadOnly = true;
            this.amountOfPurchaseRepeatTextBox.Size = new System.Drawing.Size(100, 26);
            this.amountOfPurchaseRepeatTextBox.TabIndex = 5;
            this.amountOfPurchaseRepeatTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // totalDiscountAmountLabel
            // 
            this.totalDiscountAmountLabel.AutoSize = true;
            this.totalDiscountAmountLabel.Location = new System.Drawing.Point(12, 201);
            this.totalDiscountAmountLabel.Name = "totalDiscountAmountLabel";
            this.totalDiscountAmountLabel.Size = new System.Drawing.Size(175, 20);
            this.totalDiscountAmountLabel.TabIndex = 6;
            this.totalDiscountAmountLabel.Text = "Total Discount Amount:";
            // 
            // totalDiscountAmountTextBox
            // 
            this.totalDiscountAmountTextBox.Location = new System.Drawing.Point(222, 201);
            this.totalDiscountAmountTextBox.Name = "totalDiscountAmountTextBox";
            this.totalDiscountAmountTextBox.ReadOnly = true;
            this.totalDiscountAmountTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalDiscountAmountTextBox.TabIndex = 7;
            // 
            // TotalOfSaleLabel
            // 
            this.TotalOfSaleLabel.AutoSize = true;
            this.TotalOfSaleLabel.Location = new System.Drawing.Point(12, 243);
            this.TotalOfSaleLabel.Name = "TotalOfSaleLabel";
            this.TotalOfSaleLabel.Size = new System.Drawing.Size(129, 20);
            this.TotalOfSaleLabel.TabIndex = 8;
            this.TotalOfSaleLabel.Text = "Total of the Sale:";
            // 
            // totalOfSaleTextBox
            // 
            this.totalOfSaleTextBox.Location = new System.Drawing.Point(222, 243);
            this.totalOfSaleTextBox.Name = "totalOfSaleTextBox";
            this.totalOfSaleTextBox.ReadOnly = true;
            this.totalOfSaleTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalOfSaleTextBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.totalOfSaleTextBox);
            this.Controls.Add(this.TotalOfSaleLabel);
            this.Controls.Add(this.totalDiscountAmountTextBox);
            this.Controls.Add(this.totalDiscountAmountLabel);
            this.Controls.Add(this.amountOfPurchaseRepeatTextBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.AmountRepeat);
            this.Controls.Add(this.amountOfPurchaseTextBox);
            this.Controls.Add(this.amountOfPurchaseLabel);
            this.Name = "Form1";
            this.Text = "Exit";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label amountOfPurchaseLabel;
        private System.Windows.Forms.TextBox amountOfPurchaseTextBox;
        private System.Windows.Forms.Label AmountRepeat;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox amountOfPurchaseRepeatTextBox;
        private System.Windows.Forms.Label totalDiscountAmountLabel;
        private System.Windows.Forms.TextBox totalDiscountAmountTextBox;
        private System.Windows.Forms.Label TotalOfSaleLabel;
        private System.Windows.Forms.TextBox totalOfSaleTextBox;
    }
}

